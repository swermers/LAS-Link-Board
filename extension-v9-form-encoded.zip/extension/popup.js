const SUPABASE_URL = 'https://pmhoeqxuamvqlwsatozu.supabase.co';
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBtaG9lcXh1YW12cWx3c2F0b3p1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI4MTY2NDYsImV4cCI6MjA4ODM5MjY0Nn0.ktaozIz1XrIUeUrPjtKp3VZ92BptG8xehOFsv_ny12w';

async function init() {
  const stored = await chrome.storage.local.get(null); // Get ALL storage keys

  // Show debug info from background worker
  const debugEl = document.getElementById('debugInfo');
  const debugLog = stored.lb_debug || '';
  const lbKeys = Object.keys(stored).filter(k => k.startsWith('lb_') && k !== 'lb_debug');
  const keysSummary = lbKeys.map(k => {
    const v = stored[k];
    if (typeof v === 'string' && v.length > 30) return k + '=(' + v.length + ' chars)';
    return k + '=' + JSON.stringify(v);
  }).join(' | ');
  debugEl.textContent = (debugLog ? debugLog + '\n' : '') + 'Keys: ' + (keysSummary || '(none)');
  debugEl.style.display = 'block';

  // Show any error from background OAuth attempt
  if (stored.lb_auth_error) {
    document.getElementById('loginError').textContent = stored.lb_auth_error;
    document.getElementById('loginError').style.display = 'block';
    await chrome.storage.local.remove(['lb_auth_error']);
  }

  if (stored.lb_token && stored.lb_user_id) {
    showMain(stored.lb_user_name || 'User');
  } else if (stored.lb_auth_pending) {
    // OAuth is still in progress in the background worker
    document.getElementById('loginSection').style.display = 'block';
    document.getElementById('googleBtn').textContent = 'Signing in…';
    document.getElementById('googleBtn').disabled = true;
    pollForAuth();
  } else {
    document.getElementById('loginSection').style.display = 'block';
  }
}

// Poll storage while OAuth is in progress in the background
function pollForAuth() {
  let attempts = 0;
  const maxAttempts = 60; // 30 seconds
  const interval = setInterval(async () => {
    attempts++;
    const stored = await chrome.storage.local.get([
      'lb_token', 'lb_user_id', 'lb_user_name',
      'lb_auth_error', 'lb_auth_pending'
    ]);

    if (stored.lb_token && stored.lb_user_id) {
      clearInterval(interval);
      showMain(stored.lb_user_name || 'User');
      return;
    }

    if (stored.lb_auth_error) {
      clearInterval(interval);
      document.getElementById('loginError').textContent = stored.lb_auth_error;
      document.getElementById('loginError').style.display = 'block';
      document.getElementById('googleBtn').textContent = 'Sign in with Google';
      document.getElementById('googleBtn').disabled = false;
      await chrome.storage.local.remove(['lb_auth_error']);
      return;
    }

    if (!stored.lb_auth_pending || attempts >= maxAttempts) {
      clearInterval(interval);
      document.getElementById('googleBtn').textContent = 'Sign in with Google';
      document.getElementById('googleBtn').disabled = false;
    }
  }, 500);
}

// ── Google OAuth — trigger background worker then popup will close ──
document.getElementById('googleBtn').addEventListener('click', () => {
  document.getElementById('loginError').style.display = 'none';
  chrome.runtime.sendMessage({ action: 'googleSignIn' });
});

// ── Email/Password login ──
document.getElementById('loginBtn').addEventListener('click', async () => {
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const errEl = document.getElementById('loginError');
  errEl.style.display = 'none';

  if (!email || !password) { errEl.textContent = 'Enter email and password'; errEl.style.display = 'block'; return; }

  const res = await fetch(SUPABASE_URL + '/auth/v1/token?grant_type=password', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON },
    body: JSON.stringify({ email, password })
  });
  const data = await res.json();
  if (!res.ok || !data.access_token) {
    errEl.textContent = data.error_description || data.msg || 'Login failed';
    errEl.style.display = 'block';
    return;
  }

  const name = data.user?.user_metadata?.full_name || email.split('@')[0];
  await chrome.storage.local.set({
    lb_token: data.access_token,
    lb_refresh: data.refresh_token,
    lb_user_id: data.user.id,
    lb_user_name: name
  });
  showMain(name);
});

// ── Logout ──
document.getElementById('logoutBtn').addEventListener('click', async () => {
  await chrome.storage.local.remove(['lb_token', 'lb_refresh', 'lb_user_id', 'lb_user_name', 'lb_auth_pending']);
  document.getElementById('mainSection').style.display = 'none';
  document.getElementById('loginSection').style.display = 'block';
});

function showMain(name) {
  document.getElementById('loginSection').style.display = 'none';
  document.getElementById('mainSection').style.display = 'block';
  document.getElementById('userInfo').textContent = 'Signed in as ' + name;
}

init();
